import { FaPhone, FaEnvelope } from "react-icons/fa";

export default function Contact(props) {
  //   console.log(props);
  return (
    <>
      <div className="contacts">
        <article className="contact-card">
          <img src={props.img} alt="First cat picture" />
          <h3>{props.name}</h3>
          <div className="info-group">
            <FaPhone size={14} color="#555" />
            <span> {props.phone} </span>
          </div>
          <div className="info-group">
            <FaEnvelope size={14} color="#555" />
            <p> {props.email} </p>
          </div>
        </article>
      </div>
    </>
  );
}
