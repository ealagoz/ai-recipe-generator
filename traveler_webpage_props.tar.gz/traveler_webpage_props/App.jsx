import Header from "./components/Header";
import Entry from "./components/Entry";
import TravelData from "./data";

function App() {
  const EntryElements = TravelData.map((entry) => {
    return (
      <Entry
        key={entry.id}
        {...entry} // 3. method of getting props (spreading)
        // entry={entry} // 2. method of getting props
        // img={entry.img} // 1. method of getting props
        // country={entry.country}
        // googleMapsLink={entry.googleMapsLink}
        // title={entry.title}
        // dates={entry.dates}
        // text={entry.text}
      />
    );
  });
  return (
    <>
      <Header />
      {EntryElements}
    </>
  );
}

export default App;
