export default function Joke(props) {
  console.log(props);
  return (
    <>
      <main className="jokes-container">
        <article className="jokes-content">
          <strong>
            <p className="setup">
              {" "}
              {props.id}. {props.setup}
            </p>
          </strong>
          <p className="punchline">{props.punchline}</p>
          <hr />
        </article>
      </main>
    </>
  );
}
