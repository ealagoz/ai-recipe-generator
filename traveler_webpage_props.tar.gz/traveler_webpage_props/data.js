export default [
  {
    id: 1,
    img: {
      src: "./mount_fuji.jpg",
      alt: "Mount Fuji",
    },
    title: "Mount Fuji",
    country: "Japan",
    googleMapsLink: "https://www.google.com/maps/place/Mount+Fuji",
    dates: "12 Jan, 2021 - 24 Jan, 2021",
    text: "Mount Fuji is the tallest mountain in Japan, standing at 3,776 meters (12,380 feet). Mount Fuji is the single most popular tourist site in Japan, for both Japanese and foreign tourists.",
  },
  {
    id: 2,
    img: {
      src: "./sydney_operahouse.png",
      alt: "Sydney Opera House",
    },
    title: "Sydney Opera House",
    country: "Australia",
    googleMapsLink:
      "https://www.google.com/maps/place/Sydney+Opera+House/@-33.8567844,151.213108,17z",
    dates: "27 May, 2021 - 8 Jun, 2021",
    text: "The Sydney Opera House is a multi-venue performing arts centre. Located on the banks of Sydney Harbour, it is widely regarded as one of the world's most famous and distinctive buildings and a masterpiece of 20th century architecture.",
  },
  {
    id: 3,
    img: {
      src: "./geirangerfjorden.jpg",
      alt: "Geirangerfjord",
    },
    title: "Geirangerfjord",
    country: "Norway",
    googleMapsLink:
      "https://www.google.com/maps/place/Geirangerfjord/@62.1049113,7.0051741,12z",
    dates: "01 Oct, 2021 - 18 Nov, 2021",
    text: "The Geiranger Fjord is a fjord in the Sunnmøre region of Møre og Romsdal county, Norway. It is located entirely in the Stranda Municipality. It is a 15-kilometer long branch off the Sunnylvsfjorden, which is a branch off the Storfjorden.",
  },
];
